<?php
/*
  print render($form['form_id']);
  print render($form['form_build_id']);
  print render($form['account']['name']);
  print render($form['account']['mail']);

print render( $form['field_name']);
print render($form['field_logotipe']);
print render($form['field_short_decr']);
print render($form['field_year_stand_network']);
print render($form['field_audience']);
print render($form['field_shop_points']);
print render($form['field_shop_point_1_2014']);
print render($form['field_shop_points_13_14']);
print render($form['field_profit_dynamic']);
print render($form['field_field_name_en_']);
print render($form['field_field_short_decr_en_']);
print render($form['field_field_audience_en_']);
print render($form['field_field_shop_points_en_']);


print render($form['field_job']);
print render($form['field_company']);
print render($form['field_rireit']);
print render( $form['field_fio_en']);
print render( $form['field_field_job_en_']);
print render(  $form['field_field_job_en_']);
print render(   $form['field__company_en_']);
print render(  $form['field_riteil_en_']);
  print drupal_render($form['actions']);*/
