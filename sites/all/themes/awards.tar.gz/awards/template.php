<?php
/*function awards_theme($existing, $type, $theme, $path){
    $hooks['user_register_form']=array(
        'render element'=>'form',
        'template' =>'templates/user-register',
    );
    return $hooks;
}

function awards_preprocess_user_register(&$variables) {
    $variables['form'] = drupal_build_form('user_register_form', user_register_form(array()));
}*/


