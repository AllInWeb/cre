<div class="menu-content">
    <a href="/user/retailer">
        <p>Зарегистроровать сеть!</p>
        <span>Личный кабинет ритейлера</span>
    </a>
    <a href="/user/juri">
        <p>Проголосовать!</p>
        <span>Личный кабинет жюри</span>
    </a>
</div>