<?php
/**
 * Форма ответа на вопрос о 3 лучших ретейлерах
 */
?>
<?php print render($content); ?>

<a class="voting-link" href="/">Вернуться на главную</a>